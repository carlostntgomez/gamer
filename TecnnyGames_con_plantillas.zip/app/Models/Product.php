<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use App\Models\Brand; // Add this line

class Product extends Model implements HasMedia
{
    use HasFactory, HasSlug, InteractsWithMedia;

    protected $fillable = [
        'name',
        'description',
        'price',
        // 'images' column is now handled by MediaLibrary
        'stock',
        'is_featured',
        'sku',
        'sale_price',
        'vendor',
        'type',
        'other_content',
        'colors',
        'video_url',
        'additional_info',
        'delivery_date_message',
        'seo_title',
        'seo_description',
        'seo_keywords',
        'slug',
        'condition',
        'brand_id', // Add this line
    ];

    protected $casts = [
        // 'images' is no longer a direct attribute
        'colors' => 'array',
        'additional_info' => 'array',
    ];

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    // The boot() method for deleting images is no longer needed.
    // Spatie\MediaLibrary handles this automatically.

    public function registerMediaConversions(Media $media = null): void
    {
        $this->addMediaConversion('thumb')
            ->width(150)
            ->height(150)
            ->sharpen(10);

        $this->addMediaConversion('medium')
            ->width(500)
            ->height(500)
            ->sharpen(10);

        $this->addMediaConversion('large')
            ->width(1200)
            ->height(1200)
            ->sharpen(10);

        // For WebP (better compression)
        $this->addMediaConversion('thumb-webp')
            ->width(150)
            ->height(150)
            ->format('webp')
            ->quality(85);
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('images')
            ->useFallbackUrl('/images/placeholder.jpg');
    }
}
