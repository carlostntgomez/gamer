<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Support\Facades\Storage;

class Category extends Model
{
    use HasFactory, HasSlug;

    protected $fillable = [
        'name',
        'slug',
        'parent_id',
        'seo_title',
        'seo_description',
        'seo_keywords',
        'image',
    ];

    protected $casts = [
        'seo_keywords' => 'array',
    ];

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    /**
     * Get the parent category.
     */
    public function parent()
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    /**
     * Get the child categories.
     */
    public function children()
    {
        return $this->hasMany(Category::class, 'parent_id');
    }

    /**
     * The products that belong to the category.
     */
    public function products()
    {
        return $this->belongsToMany(Product::class);
    }

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Category $category) {
            // Establecer el parent_id de los hijos a null
            $category->children()->update(['parent_id' => null]);

            // Eliminar la imagen asociada
            if ($category->image) {
                Storage::disk('public')->delete($category->image);
            }
        });

        static::updating(function (Category $category) {
            // Verificar si la imagen ha cambiado y eliminar la antigua
            if ($category->isDirty('image') && ($oldImage = $category->getOriginal('image'))) {
                Storage::disk('public')->delete($oldImage);
            }
        });
    }
}