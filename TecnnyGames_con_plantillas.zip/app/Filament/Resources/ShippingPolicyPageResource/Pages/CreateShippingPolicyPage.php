<?php

namespace App\Filament\Resources\ShippingPolicyPageResource\Pages;

use App\Filament\Resources\ShippingPolicyPageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateShippingPolicyPage extends CreateRecord
{
    protected static string $resource = ShippingPolicyPageResource::class;
}
