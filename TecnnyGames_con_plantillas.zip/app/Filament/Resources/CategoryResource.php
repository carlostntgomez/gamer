<?php

namespace App\Filament\Resources;

use App\Filament\Resources\CategoryResource\Pages;
use App\Filament\Resources\CategoryResource\RelationManagers;
use App\Models\Category;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Filament\Forms\Components\FileUpload as FileUploadComponent;

class CategoryResource extends Resource
{
    protected static ?string $model = Category::class;

    protected static ?string $navigationIcon = 'heroicon-o-tag';
    protected static ?string $navigationGroup = 'E-commerce';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Group::make()
                    ->schema([
                        Forms\Components\Section::make('Información de la Categoría')
                            ->schema([
                                Forms\Components\TextInput::make('name')
                                    ->label('Nombre')
                                    ->required()
                                    ->maxLength(255)
                                    ->live(onBlur: true)
                                    ->afterStateUpdated(fn ($state, callable $set) => $set('slug', Str::slug($state))),
                                Forms\Components\TextInput::make('slug')
                                    ->label('Slug')
                                    ->required()
                                    ->unique(ignoreRecord: true)
                                    ->maxLength(255),
                                Forms\Components\Select::make('parent_id')
                                    ->label('Categoría Padre')
                                    ->relationship('parent', 'name')
                                    ->searchable()
                                    ->preload()
                                    ->placeholder('Seleccione una categoría padre'),
                            ])->columns(1),
                        Forms\Components\Section::make('Imágenes')
                            ->schema([
                                Forms\Components\FileUpload::make('image')
                                    ->label('Imagen de la Categoría')
                                    ->directory('categories')
                                    ->disk('public')
                                    ->visibility('public')
                                    ->image()
                                    ->maxSize(5120) // 5MB máximo
                                    ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/gif', 'image/webp'])
                                    ->nullable()
                                    ->saveUploadedFileUsing(function (TemporaryUploadedFile $file, FileUploadComponent $component, ?Category $record): ?string {
                                        try {
                                            // Obtener el nombre de la categoría del formulario
                                            $categoryName = $component->getLivewire()->data['name'] ?? 'categoria';
                                            $customFileName = Str::slug($categoryName) . '.webp';
                                            $directory = $component->getDirectory();
                                            
                                            // Si es una actualización y existe imagen anterior, eliminarla
                                            if ($record && $record->image) {
                                                Storage::disk('public')->delete($record->image);
                                            }

                                            // Convertir imagen a WebP
                                            $webpPath = self::convertToWebP($file, $customFileName);
                                            
                                            if (!$webpPath) {
                                                throw new \Exception('No se pudo convertir la imagen a WebP');
                                            }

                                            // Crear nuevo UploadedFile
                                            $webpFile = new UploadedFile(
                                                $webpPath,
                                                $customFileName,
                                                'image/webp',
                                                null,
                                                true
                                            );

                                            // Almacenar y retornar ruta
                                            $storedPath = Storage::disk('public')->putFileAs($directory, $webpFile, $customFileName);
                                            
                                            // Limpiar archivo temporal
                                            @unlink($webpPath);
                                            
                                            return $storedPath;
                                        } catch (\Exception $e) {
                                            Log::error('Error al subir imagen de categoría: ' . $e->getMessage());
                                            return null;
                                        }
                                    })
                                    ->deleteUploadedFileUsing(function (string $file) {
                                        Storage::disk('public')->delete($file);
                                    }),
                            ]),
                    ])->columnSpan(2),

                Forms\Components\Group::make()
                    ->schema([
                        Forms\Components\Section::make('SEO')
                            ->schema([
                                Forms\Components\TextInput::make('seo_title')
                                    ->label('Título SEO')
                                    ->maxLength(60)
                                    ->nullable()
                                    ->helperText('Máximo 60 caracteres recomendados'),
                                Forms\Components\Textarea::make('seo_description')
                                    ->label('Descripción SEO')
                                    ->maxLength(160)
                                    ->rows(3)
                                    ->nullable()
                                    ->helperText('Máximo 160 caracteres recomendados'),
                                Forms\Components\TagsInput::make('seo_keywords')
                                    ->label('Palabras Clave SEO')
                                    ->nullable()
                                    ->placeholder('Presione Enter para agregar'),
                            ]),
                    ])->columnSpan(1),
            ])->columns(3);
    }

    /**
     * Convierte una imagen a formato WebP
     */
    protected static function convertToWebP(TemporaryUploadedFile $file, string $fileName): ?string
    {
        try {
            $tempPath = sys_get_temp_dir() . '/' . $fileName;
            $imageResource = null;
            $mimeType = $file->getMimeType();

            // Cargar imagen según tipo
            switch ($mimeType) {
                case 'image/jpeg':
                case 'image/jpg':
                    $imageResource = @imagecreatefromjpeg($file->getRealPath());
                    break;
                case 'image/png':
                    $imageResource = @imagecreatefrompng($file->getRealPath());
                    if ($imageResource) {
                        imagealphablending($imageResource, false);
                        imagesavealpha($imageResource, true);
                    }
                    break;
                case 'image/gif':
                    $imageResource = @imagecreatefromgif($file->getRealPath());
                    break;
                case 'image/webp':
                    $imageResource = @imagecreatefromwebp($file->getRealPath());
                    break;
            }

            if (!$imageResource) {
                Log::error("No se pudo crear el recurso de imagen desde: {$mimeType}");
                return null;
            }

            // Convertir a WebP
            $success = imagewebp($imageResource, $tempPath, 95);
            imagedestroy($imageResource);

            return $success ? $tempPath : null;
        } catch (\Exception $e) {
            Log::error('Error en conversión WebP: ' . $e->getMessage());
            return null;
        }
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->label('Imagen')
                    ->circular()
                    ->defaultImageUrl(url('/images/placeholder-category.png')),
                Tables\Columns\TextColumn::make('name')
                    ->label('Nombre')
                    ->sortable()
                    ->searchable(),
                Tables\Columns\TextColumn::make('slug')
                    ->label('Slug')
                    ->sortable()
                    ->searchable()
                    ->copyable()
                    ->copyMessage('Slug copiado'),
                Tables\Columns\TextColumn::make('parent.name')
                    ->label('Categoría Padre')
                    ->sortable()
                    ->default('—'),
                Tables\Columns\TextColumn::make('seo_title')
                    ->label('Título SEO')
                    ->toggleable(isToggledHiddenByDefault: true)
                    ->limit(30),
                Tables\Columns\TextColumn::make('seo_description')
                    ->label('Descripción SEO')
                    ->limit(50)
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Creado')
                    ->dateTime('d/m/Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->label('Actualizado')
                    ->dateTime('d/m/Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('parent_id')
                    ->label('Categoría Padre')
                    ->relationship('parent', 'name')
                    ->placeholder('Todas las categorías'),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->modal()
                    ->modalWidth('5xl'),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->modal()
                    ->modalWidth('5xl'),
            ])
            ->defaultSort('name', 'asc');
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCategories::route('/'),
        ];
    }

    /**
     * Método llamado antes de guardar el registro
     */
    protected static function mutateFormDataBeforeSave(array $data): array
    {
        // Generar slug automáticamente si no está presente
        if (empty($data['slug']) && !empty($data['name'])) {
            $data['slug'] = Str::slug($data['name']);
        }

        return $data;
    }

    /**
     * Método llamado después de guardar el registro (para edición)
     */
    protected static function afterSave($record, array $data): void
    {
        // Solo ejecutar si hay imagen y el nombre cambió
        if ($record->wasChanged('name') && $record->image) {
            $directory = 'categories';
            $oldImagePath = $record->image;
            $oldImageFileName = basename($oldImagePath);
            
            // Generar nuevo nombre basado en el nuevo slug
            $newSlug = Str::slug($record->name);
            $newFileName = $newSlug . '.webp';
            $newImagePath = $directory . '/' . $newFileName;

            // Solo renombrar si el nombre es diferente
            if ($oldImageFileName !== $newFileName) {
                try {
                    // Verificar que el archivo antiguo existe
                    if (Storage::disk('public')->exists($oldImagePath)) {
                        // Si ya existe una imagen con el nuevo nombre, eliminarla primero
                        if (Storage::disk('public')->exists($newImagePath) && $oldImagePath !== $newImagePath) {
                            Storage::disk('public')->delete($newImagePath);
                        }
                        
                        // Mover/renombrar la imagen
                        $moved = Storage::disk('public')->move($oldImagePath, $newImagePath);
                        
                        if ($moved) {
                            // Actualizar la ruta en la base de datos sin disparar eventos
                            $record->updateQuietly(['image' => $newImagePath]);
                            Log::info("Imagen de categoría renombrada: {$oldImagePath} → {$newImagePath}");
                        } else {
                            Log::error("No se pudo mover la imagen de {$oldImagePath} a {$newImagePath}");
                        }
                    } else {
                        Log::warning("La imagen {$oldImagePath} no existe en el disco");
                    }
                } catch (\Exception $e) {
                    Log::error("Error al renombrar imagen de categoría: {$e->getMessage()}");
                }
            }
        }
    }
}
