<?php

namespace App\Filament\Resources\PaymentPolicyPageResource\Pages;

use App\Filament\Resources\PaymentPolicyPageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePaymentPolicyPage extends CreateRecord
{
    protected static string $resource = PaymentPolicyPageResource::class;
}
