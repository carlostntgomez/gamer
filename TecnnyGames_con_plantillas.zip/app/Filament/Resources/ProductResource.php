<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Filament\Resources\ProductResource\RelationManagers;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
// New Imports for Spatie Media Library
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    protected static ?string $navigationIcon = 'heroicon-o-cube';
    protected static ?string $navigationGroup = 'E-commerce';

    public static function getRecordRouteKeyName(): ?string
    {
        return 'slug';
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Group::make()
                    ->schema([
                        Forms\Components\Section::make('Información del Producto')
                            ->schema([
                                Forms\Components\TextInput::make('name')
                                    ->label('Nombre')
                                    ->required()
                                    ->maxLength(255),
                                Forms\Components\TextInput::make('sku')
                                    ->label('SKU')
                                    ->maxLength(255)
                                    ->nullable(),
                                Forms\Components\RichEditor::make('description')
                                    ->label('Descripción')
                                    ->maxLength(65535),
                                Forms\Components\RichEditor::make('other_content')
                                    ->label('Otro Contenido')
                                    ->maxLength(65535),
                            ]),
                        Forms\Components\Section::make('Inventario')
                            ->schema([
                                Forms\Components\TextInput::make('price')
                                    ->label('Precio')
                                    ->numeric()
                                    ->required()
                                    ->prefix('$'),
                                Forms\Components\TextInput::make('sale_price')
                                    ->label('Precio de Oferta')
                                    ->numeric()
                                    ->nullable()
                                    ->prefix('$'),
                                Forms\Components\TextInput::make('stock')
                                    ->label('Stock')
                                    ->numeric()
                                    ->required()
                                    ->default(0),
                            ])->columns(2),
                        // Media Library section
                        Forms\Components\Section::make('Imágenes')
                            ->schema([
                                SpatieMediaLibraryFileUpload::make('images')
                                    ->collection('images')
                                    ->label('Imágenes del producto')
                                    ->image()
                                    ->multiple()
                                    ->maxFiles(5)
                                    ->imageEditor()
                                    ->reorderable()
                                    ->conversion('thumb') // For admin preview
                                    ->columnSpanFull(),
                            ]),
                    ])->columnSpan(2),

                Forms\Components\Group::make()
                    ->schema([
                        Forms\Components\Section::make('Detalles')
                            ->schema([
                                Forms\Components\Select::make('categories')
                                    ->label('Categorías')
                                    ->relationship('categories', 'name')
                                    ->multiple()
                                    ->searchable()
                                    ->preload(),
                                Forms\Components\Select::make('brand_id')
                                    ->label('Marca')
                                    ->relationship('brand', 'name')
                                    ->searchable()
                                    ->preload()
                                    ->nullable(),
                                Forms\Components\Select::make('condition')
                                    ->label('Condición')
                                    ->options([
                                        'nuevo' => 'Nuevo',
                                        'usado' => 'Usado',
                                    ])
                                    ->required(),
                                Forms\Components\Select::make('vendor')
                                    ->label('Vendedor')
                                    ->options([
                                        'sony' => 'Sony',
                                        'microsoft' => 'Microsoft',
                                        'nintendo' => 'Nintendo',
                                        'samsung' => 'Samsung',
                                        'apple' => 'Apple',
                                        // Añadir más opciones aquí
                                    ])
                                    ->searchable()
                                    ->nullable(),
                                Forms\Components\Select::make('type')
                                    ->label('Tipo')
                                    ->options([
                                        'gadget' => 'Gadget',
                                        'videojuego' => 'Videojuego',
                                        'accesorio' => 'Accesorio',
                                        // Añadir más opciones aquí
                                    ])
                                    ->searchable()
                                    ->nullable(),
                                Forms\Components\TagsInput::make('colors')
                                    ->label('Colores disponibles')
                                    ->placeholder('Añadir color')
                                    ->splitKeys(['Tab', ',']),
                                Forms\Components\TextInput::make('video_url')
                                    ->label('URL del Video (YouTube)')
                                    ->url()
                                    ->nullable(),
                                Forms\Components\KeyValue::make('additional_info')
                                    ->label('Información Adicional')
                                    ->keyLabel('Atributo')
                                    ->valueLabel('Valor')
                                    ->nullable(),
                                Forms\Components\TextInput::make('delivery_date_message')
                                    ->label('Mensaje de Fecha de Entrega')
                                    ->placeholder('Ej: El artículo será entregado el o antes del')
                                    ->nullable(),
                                Forms\Components\Toggle::make('is_featured')
                                    ->label('Destacado')
                                    ->required(),
                            ]),
                        Forms\Components\Section::make('SEO')
                            ->schema([
                                Forms\Components\TextInput::make('seo_title')
                                    ->label('Título SEO')
                                    ->maxLength(255),
                                Forms\Components\Textarea::make('seo_description')
                                    ->label('Descripción SEO')
                                    ->maxLength(65535),
                                Forms\Components\TagsInput::make('seo_keywords')
                                    ->label('Palabras Clave SEO'),
                                Forms\Components\TextInput::make('slug')
                                    ->label('Slug (URL Amigable)')
                                    ->disabled()
                                    ->maxLength(255),
                            ]),
                    ])->columnSpan(1),
            ])->columns(3);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                SpatieMediaLibraryImageColumn::make('images')
                    ->label('Imágenes')
                    ->collection('images')
                    ->conversion('thumb')
                    ->circular()
                    ->stacked()
                    ->limit(3),
                Tables\Columns\TextColumn::make('name')
                    ->label('Nombre')
                    ->searchable(),
                Tables\Columns\TextColumn::make('slug')
                    ->label('Slug')
                    ->searchable(),
                Tables\Columns\TextColumn::make('sku')
                    ->label('SKU')
                    ->searchable(),
                Tables\Columns\TextColumn::make('price')
                    ->label('Precio')
                    ->money('usd')
                    ->sortable(),
                Tables\Columns\TextColumn::make('stock')
                    ->label('Stock')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\IconColumn::make('is_featured')
                    ->label('Destacado')
                    ->boolean(),
                Tables\Columns\TextColumn::make('categories.name')
                    ->label('Categorías')
                    ->badge(),
                Tables\Columns\TextColumn::make('brand.name')
                    ->label('Marca')
                    ->searchable()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: false),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Creado')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->label('Actualizado')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('categories')
                    ->label('Categoría')
                    ->relationship('categories', 'name')
                    ->searchable()
                    ->multiple(),
                Tables\Filters\SelectFilter::make('condition')
                    ->label('Condición')
                    ->options([
                        'nuevo' => 'Nuevo',
                        'usado' => 'Usado',
                    ]),
                Tables\Filters\TernaryFilter::make('is_featured')
                    ->label('Destacado'),
            ])
            ->actions([
                Tables\Actions\ViewAction::make()->modal(),
                Tables\Actions\EditAction::make()->modal(),
                Tables\Actions\Action::make('view_on_web')
                    ->label('Ver en la Web')
                    ->icon('heroicon-o-arrow-top-right-on-square')
                    ->url(fn (Product $record): ?string => $record->slug ? route('product.show', $record->slug) : null)
                    ->openUrlInNewTab()
                    ->hidden(fn (Product $record): bool => empty($record->slug)),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()->modal(),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\ReviewsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
        ];
    }
}