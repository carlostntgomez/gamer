<?php

namespace App\Filament\Resources\ReturnPolicyPageResource\Pages;

use App\Filament\Resources\ReturnPolicyPageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReturnPolicyPage extends CreateRecord
{
    protected static string $resource = ReturnPolicyPageResource::class;
}
