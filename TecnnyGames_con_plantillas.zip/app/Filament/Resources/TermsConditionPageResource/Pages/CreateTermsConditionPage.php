<?php

namespace App\Filament\Resources\TermsConditionPageResource\Pages;

use App\Filament\Resources\TermsConditionPageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTermsConditionPage extends CreateRecord
{
    protected static string $resource = TermsConditionPageResource::class;
}
