<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DiscountResource\Pages;
use App\Filament\Resources\DiscountResource\RelationManagers;
use App\Models\Category;
use App\Models\Discount;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class DiscountResource extends Resource
{
    protected static ?string $model = Discount::class;

    protected static ?string $navigationIcon = 'heroicon-o-gift';
    protected static ?string $navigationGroup = 'E-commerce';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Group::make()
                    ->schema([
                        Forms\Components\Section::make('Detalles del Descuento')
                            ->schema([
                                Forms\Components\TextInput::make('code')
                                    ->label('Código')
                                    ->required()
                                    ->unique(ignoreRecord: true)
                                    ->maxLength(255),
                                Forms\Components\Select::make('type')
                                    ->label('Tipo de Descuento')
                                    ->options([
                                        'percentage' => 'Porcentaje',
                                        'fixed' => 'Cantidad Fija',
                                    ])
                                    ->required()
                                    ->native(false)
                                    ->live(),
                                Forms\Components\TextInput::make('value')
                                    ->label('Valor')
                                    ->numeric()
                                    ->required()
                                    ->suffix(fn (Forms\Get $get): string => $get('type') === 'percentage' ? '%' : '$'),
                                Forms\Components\TextInput::make('min_amount')
                                    ->label('Cantidad Mínima de Compra')
                                    ->numeric()
                                    ->nullable()
                                    ->prefix('$'),
                                Forms\Components\TextInput::make('max_uses')
                                    ->label('Usos Máximos')
                                    ->numeric()
                                    ->nullable(),
                                Forms\Components\Toggle::make('is_active')
                                    ->label('Activo')
                                    ->default(false),
                            ])->columns(2),

                        Forms\Components\Section::make('Fechas de Validez')
                            ->schema([
                                Forms\Components\DateTimePicker::make('starts_at')
                                    ->label('Fecha de Inicio')
                                    ->native(false)
                                    ->nullable(),
                                Forms\Components\DateTimePicker::make('expires_at')
                                    ->label('Fecha de Caducidad')
                                    ->native(false)
                                    ->nullable(),
                            ])->columns(2),
                    ])->columnSpan(2),

                Forms\Components\Group::make()
                    ->schema([
                        Forms\Components\Section::make('Aplicabilidad')
                            ->schema([
                                Forms\Components\Select::make('applies_to')
                                    ->label('Aplica a')
                                    ->options([
                                        'all' => 'Todos los productos',
                                        'products' => 'Productos específicos',
                                        'categories' => 'Categorías específicas',
                                    ])
                                    ->required()
                                    ->native(false)
                                    ->live(),
                                Forms\Components\Select::make('product_ids')
                                    ->label('Productos')
                                    ->multiple()
                                    ->searchable()
                                    ->preload()
                                    ->options(Product::pluck('name', 'id'))
                                    ->visible(fn (Forms\Get $get): bool => $get('applies_to') === 'products'),
                                Forms\Components\Select::make('category_ids')
                                    ->label('Categorías')
                                    ->multiple()
                                    ->searchable()
                                    ->preload()
                                    ->options(Category::pluck('name', 'id'))
                                    ->visible(fn (Forms\Get $get): bool => $get('applies_to') === 'categories'),
                            ]),
                    ])->columnSpan(1),
            ])->columns(3);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('code')
                    ->label('Código')
                    ->searchable()
                    ->sortable()
                    ->copyable(),
                Tables\Columns\TextColumn::make('type')
                    ->label('Tipo')
                    ->sortable()
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'percentage' => 'Porcentaje',
                        'fixed' => 'Cantidad Fija',
                        default => $state,
                    }),
                Tables\Columns\TextColumn::make('value')
                    ->label('Valor')
                    ->numeric()
                    ->sortable()
                    ->formatStateUsing(fn (string $state, Discount $record): string => $record->type === 'percentage' ? "{$state}%" : "$ {$state}"),
                Tables\Columns\TextColumn::make('min_amount')
                    ->label('Mín. Compra')
                    ->money('usd')
                    ->sortable(),
                Tables\Columns\TextColumn::make('uses')
                    ->label('Usos')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('max_uses')
                    ->label('Máx. Usos')
                    ->numeric()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\IconColumn::make('is_active')
                    ->label('Activo')
                    ->boolean(),
                Tables\Columns\TextColumn::make('starts_at')
                    ->label('Inicia')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('expires_at')
                    ->label('Expira')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('applies_to')
                    ->label('Aplica a')
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'all' => 'Todos los productos',
                        'products' => 'Productos específicos',
                        'categories' => 'Categorías específicas',
                        default => $state,
                    })
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('type')
                    ->label('Tipo de Descuento')
                    ->options([
                        'percentage' => 'Porcentaje',
                        'fixed' => 'Cantidad Fija',
                    ]),
                Tables\Filters\SelectFilter::make('applies_to')
                    ->label('Aplica a')
                    ->options([
                        'all' => 'Todos los productos',
                        'products' => 'Productos específicos',
                        'categories' => 'Categorías específicas',
                    ]),
                Tables\Filters\TernaryFilter::make('is_active')
                    ->label('Estado')
                    ->trueLabel('Activo')
                    ->falseLabel('Inactivo')
                    ->placeholder('Todos'),
            ])
            ->actions([
                Tables\Actions\ViewAction::make()->modal(),
                Tables\Actions\EditAction::make()->modal(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()->modal(),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDiscounts::route('/'),
            'create' => Pages\CreateDiscount::route('/create'),
            'edit' => Pages\EditDiscount::route('/{record}/edit'),
        ];
    }
}
