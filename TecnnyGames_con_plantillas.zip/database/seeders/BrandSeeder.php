<?php

namespace Database\Seeders;

use App\Models\Brand;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BrandSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('brands')->truncate();

        $brands = [
            'Sony',
            'Microsoft',
            'Nintendo',
            'Valve',
            'Logitech',
            'Razer',
            'Corsair',
            'HyperX',
            'Alienware',
            'HP Omen',
        ];

        foreach ($brands as $brandName) {
            Brand::factory()->create([
                'name' => $brandName,
            ]);
        }
    }
}
