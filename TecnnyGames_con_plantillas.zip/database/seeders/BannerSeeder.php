<?php

namespace Database\Seeders;

use App\Models\Banner;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;


class BannerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $driver = DB::connection()->getDriverName();
        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        }

        DB::table('banners')->truncate();

        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        }

        // Get the list of available sample images
        $imagePath = public_path('imagenes de muestra');
        $imageFiles = File::files($imagePath);

        if (empty($imageFiles)) {
            $this->command->warn('No sample images found in public/imagenes de muestra. Seeding banners without images.');
            Banner::factory()->count(5)->create();
            return;
        }

        Banner::factory()
            ->count(5)
            ->create()
            ->each(function (Banner $banner) use ($imageFiles) {
                // Attach a random image as banner_image
                $randomImageFile = fake()->randomElement($imageFiles);
                $banner->addMedia($randomImageFile->getRealPath())
                    ->preservingOriginal()
                    ->toMediaCollection('banner_image');
            });
    }
}
