<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\Review;
use Illuminate\Support\Facades\File;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Truncate tables to ensure a clean state
        $driver = DB::connection()->getDriverName();
        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        }

        DB::table('products')->truncate();
        DB::table('media')->truncate();
        DB::table('category_product')->truncate();

        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        }

        // Get leaf categories (categories without children)
        $categoryIds = Category::doesntHave('children')->pluck('id')->toArray();
        if (empty($categoryIds)) {
            $this->command->error('No leaf categories found. Please run the CategorySeeder first.');
            return;
        }

        // Get the list of available sample images
        $imagePath = public_path('imagenes de muestra');
        $imageFiles = File::files($imagePath);

        // Create products and attach media if images are available
        if (empty($imageFiles)) {
            $this->command->warn('No sample images found in public/imagenes de muestra. Seeding products without images.');
            Product::factory()
                ->count(5) // Increased count
                ->has(Review::factory()->count(rand(1, 5)))
                ->create()->each(function (Product $product) use ($categoryIds) {
                    // Attach 1 or 2 random categories
                    $randomCategoryKeys = array_rand($categoryIds, rand(1, 2));
                    if (!is_array($randomCategoryKeys)) {
                        $randomCategoryKeys = [$randomCategoryKeys];
                    }
                    $categoriesToSync = array_map(fn($key) => $categoryIds[$key], $randomCategoryKeys);
                    $product->categories()->sync($categoriesToSync);
                });
            return;
        }

        Product::factory()
            ->count(5) // Increased count
            ->has(Review::factory()->count(rand(1, 5)))
            ->create()
            ->each(function (Product $product) use ($imageFiles, $categoryIds) {
                // Attach 1 to 3 random images to each product
                $numberOfImages = rand(1, 3);
                $randomImageKeys = array_rand($imageFiles, $numberOfImages);

                if (!is_array($randomImageKeys)) {
                    $randomImageKeys = [$randomImageKeys];
                }

                foreach ($randomImageKeys as $index) {
                    $product->addMedia($imageFiles[$index]->getRealPath())
                            ->preservingOriginal()
                            ->toMediaCollection('images');
                }

                // Attach 1 or 2 random categories
                $randomCategoryKeys = array_rand($categoryIds, rand(1, 2));
                if (!is_array($randomCategoryKeys)) {
                    $randomCategoryKeys = [$randomCategoryKeys];
                }
                $categoriesToSync = array_map(fn($key) => $categoryIds[$key], $randomCategoryKeys);
                $product->categories()->sync($categoriesToSync);
            });
    }
}
