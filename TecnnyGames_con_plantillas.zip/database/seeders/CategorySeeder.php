<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('category_product')->truncate();
        DB::table('categories')->truncate();

        // Limpiar el directorio de imágenes de categorías y recrearlo
        Storage::disk('public')->deleteDirectory('categories');
        Storage::disk('public')->makeDirectory('categories');

        // Obtener la lista de imágenes de muestra
        $sampleImagesPath = public_path('imagenes de muestra');
        $sampleImages = File::files($sampleImagesPath);

        // Función para obtener una imagen aleatoria y copiarla, convirtiéndola a WebP
        $getRandomImageAndCopy = function($categorySlug) use ($sampleImages) {
            if (empty($sampleImages)) {
                return null; // No hay imágenes de muestra disponibles
            }
            // Seleccionar una imagen aleatoria
            $randomImagePath = $sampleImages[array_rand($sampleImages)]->getPathname();
            $destinationFileName = $categorySlug . '.webp'; // Siempre .webp
            $destinationPath = 'categories/' . $destinationFileName;

            if (file_exists($randomImagePath)) {
                $imageResource = null;
                $mimeType = mime_content_type($randomImagePath);

                if (in_array($mimeType, ['image/jpeg', 'image/jpg'])) {
                    $imageResource = imagecreatefromjpeg($randomImagePath);
                } elseif ($mimeType === 'image/png') {
                    $imageResource = imagecreatefrompng($randomImagePath);
                    imagealphablending($imageResource, false);
                    imagesavealpha($imageResource, true);
                } elseif ($mimeType === 'image/gif') {
                    $imageResource = imagecreatefromgif($randomImagePath);
                }

                if ($imageResource) {
                    $tempWebpPath = sys_get_temp_dir() . '/' . Str::uuid() . '.webp';
                    imagewebp($imageResource, $tempWebpPath, 95); // Calidad del 95%
                    imagedestroy($imageResource); // Liberar memoria

                    Storage::disk('public')->put($destinationPath, file_get_contents($tempWebpPath));
                    unlink($tempWebpPath); // Eliminar archivo temporal
                    return $destinationPath;
                }
            }
            return null; // Retornar null si falla o no es un tipo soportado
        };

        $videojuegos = Category::create([
            'name' => 'Videojuegos',
            'slug' => Str::slug('Videojuegos'),
            'seo_title' => 'Los mejores videojuegos y consolas',
            'seo_description' => 'Descubre nuestra amplia selección de videojuegos para todas las plataformas, desde PS5 hasta Nintendo Switch.',
            'seo_keywords' => ['videojuegos', 'consolas', 'gaming', 'ps5', 'xbox', 'nintendo switch'],
            'image' => $getRandomImageAndCopy(Str::slug('Videojuegos')),
        ]);
        $celulares = Category::create([
            'name' => 'Celulares y Wearables',
            'slug' => Str::slug('Celulares y Wearables'),
            'seo_title' => 'Smartphones y dispositivos vestibles',
            'seo_description' => 'Encuentra los últimos modelos de celulares, smartwatches y accesorios para estar siempre conectado.',
            'seo_keywords' => ['celulares', 'smartphones', 'wearables', 'smartwatch', 'audifonos'],
            'image' => $getRandomImageAndCopy(Str::slug('Celulares y Wearables')),
        ]);
        $computacion = Category::create([
            'name' => 'Computación',
            'slug' => Str::slug('Computación'),
            'seo_title' => 'Equipos y componentes de computación',
            'seo_description' => 'Todo para tu PC: laptops, componentes, periféricos y accesorios de computación.',
            'seo_keywords' => ['computacion', 'laptops', 'pc gaming', 'componentes pc'],
            'image' => $getRandomImageAndCopy(Str::slug('Computación')),
        ]);
        $audioVideo = Category::create([
            'name' => 'Audio y Video',
            'slug' => Str::slug('Audio y Video'),
            'seo_title' => 'Equipos de audio y video de alta calidad',
            'seo_description' => 'Auriculares, bocinas, cámaras y drones para una experiencia multimedia inmersiva.',
            'seo_keywords' => ['audio', 'video', 'auriculares', 'bocinas', 'drones', 'camaras'],
            'image' => $getRandomImageAndCopy(Str::slug('Audio y Video')),
        ]);
        $accesorios = Category::create([
            'name' => 'Accesorios',
            'slug' => Str::slug('Accesorios'),
            'seo_title' => 'Accesorios tecnológicos para todos tus dispositivos',
            'seo_description' => 'Cables, adaptadores, mochilas y otros gadgets para complementar tu tecnología.',
            'seo_keywords' => ['accesorios', 'gadgets', 'cables', 'mochilas'],
            'image' => $getRandomImageAndCopy(Str::slug('Accesorios')),
        ]);

        $juegos = Category::create([
            'name' => 'Juegos',
            'slug' => Str::slug('Juegos'),
            'parent_id' => $videojuegos->id,
            'seo_title' => 'Comprar juegos para consolas y PC',
            'seo_description' => 'Gran variedad de juegos para PlayStation, Xbox, Nintendo Switch y PC. ¡Encuentra tu próximo título favorito!',
            'seo_keywords' => ['juegos ps5', 'juegos xbox', 'juegos nintendo switch', 'juegos pc'],
            'image' => $getRandomImageAndCopy(Str::slug('Juegos')),
        ]);
        $accesoriosGaming = Category::create([
            'name' => 'Accesorios de Gaming',
            'slug' => Str::slug('Accesorios de Gaming'),
            'parent_id' => $videojuegos->id,
            'seo_title' => 'Accesorios esenciales para gamers',
            'seo_description' => 'Mandos, auriculares, teclados y monitores gamer para potenciar tu experiencia de juego.',
            'seo_keywords' => ['accesorios gaming', 'mandos', 'headsets', 'teclados gamer'],
            'image' => $getRandomImageAndCopy(Str::slug('Accesorios de Gaming')),
        ]);
        $realidadVirtual = Category::create([
            'name' => 'Realidad Virtual',
            'slug' => Str::slug('Realidad Virtual'),
            'parent_id' => $videojuegos->id,
            'seo_title' => 'Sumérgete en la realidad virtual',
            'seo_description' => 'Explora los mejores dispositivos y experiencias de realidad virtual.',
            'seo_keywords' => ['realidad virtual', 'vr', 'cascos vr'],
            'image' => $getRandomImageAndCopy(Str::slug('Realidad Virtual')),
        ]);

        Category::create([
            'name' => 'Juegos para PlayStation 5',
            'slug' => Str::slug('Juegos para PlayStation 5'),
            'parent_id' => $juegos->id,
            'seo_title' => 'Juegos PS5',
            'seo_description' => 'Los últimos y mejores juegos para tu consola PlayStation 5.',
            'seo_keywords' => ['juegos ps5', 'playstation 5'],
            'image' => $getRandomImageAndCopy(Str::slug('Juegos para PlayStation 5')),
        ]);
        Category::create([
            'name' => 'Juegos para PlayStation 4',
            'slug' => Str::slug('Juegos para PlayStation 4'),
            'parent_id' => $juegos->id,
            'seo_title' => 'Juegos PS4',
            'seo_description' => 'Amplio catálogo de juegos para PlayStation 4, desde clásicos hasta novedades.',
            'seo_keywords' => ['juegos ps4', 'playstation 4'],
            'image' => $getRandomImageAndCopy(Str::slug('Juegos para PlayStation 4')),
        ]);
        Category::create([
            'name' => 'Juegos para Xbox Series X/S',
            'slug' => Str::slug('Juegos para Xbox Series X/S'),
            'parent_id' => $juegos->id,
            'seo_title' => 'Juegos Xbox Series X/S',
            'seo_description' => 'Descubre los títulos más emocionantes para Xbox Series X y Series S.',
            'seo_keywords' => ['juegos xbox series x', 'juegos xbox series s'],
            'image' => $getRandomImageAndCopy(Str::slug('Juegos para Xbox Series X/S')),
        ]);
        Category::create([
            'name' => 'Juegos para Nintendo Switch',
            'slug' => Str::slug('Juegos para Nintendo Switch'),
            'parent_id' => $juegos->id,
            'seo_title' => 'Juegos Nintendo Switch',
            'seo_description' => 'La mejor selección de juegos para la consola híbrida de Nintendo.',
            'seo_keywords' => ['juegos nintendo switch', 'nintendo switch'],
            'image' => $getRandomImageAndCopy(Str::slug('Juegos para Nintendo Switch')),
        ]);

        Category::create([
            'name' => 'Mandos y Controles',
            'slug' => Str::slug('Mandos y Controles'),
            'parent_id' => $accesoriosGaming->id,
            'seo_title' => 'Mandos y controles para todas las plataformas',
            'seo_description' => 'Encuentra el mando perfecto para tu consola o PC y mejora tu precisión.',
            'seo_keywords' => ['mandos gaming', 'controles ps5', 'controles xbox'],
            'image' => $getRandomImageAndCopy(Str::slug('Mandos y Controles')),
        ]);
        Category::create([
            'name' => 'Auriculares (Headsets)',
            'slug' => Str::slug('Auriculares (Headsets)'),
            'parent_id' => $accesoriosGaming->id,
            'seo_title' => 'Auriculares gaming de alta fidelidad',
            'seo_description' => 'Sumérgete en el juego con nuestros headsets gaming con sonido envolvente y micrófono claro.',
            'seo_keywords' => ['auriculares gaming', 'headsets', 'cascos gaming'],
            'image' => $getRandomImageAndCopy(Str::slug('Auriculares (Headsets)')),
        ]);
        Category::create([
            'name' => 'Teclados y Ratones Gamer',
            'slug' => Str::slug('Teclados y Ratones Gamer'),
            'parent_id' => $accesoriosGaming->id,
            'seo_title' => 'Teclados y ratones gaming profesionales',
            'seo_description' => 'Periféricos de alta precisión para los gamers más exigentes.',
            'seo_keywords' => ['teclados gamer', 'ratones gamer', 'perifericos gaming'],
            'image' => $getRandomImageAndCopy(Str::slug('Teclados y Ratones Gamer')),
        ]);
        Category::create([
            'name' => 'Monitores Gamer',
            'slug' => Str::slug('Monitores Gamer'),
            'parent_id' => $accesoriosGaming->id,
            'seo_title' => 'Monitores gaming de alta frecuencia',
            'seo_description' => 'Experimenta una fluidez sin igual con nuestros monitores gaming de última generación.',
            'seo_keywords' => ['monitores gamer', 'monitores 144hz', 'monitores 240hz'],
            'image' => $getRandomImageAndCopy(Str::slug('Monitores Gamer')),
        ]);

        Category::create([
            'name' => 'Smartphones',
            'slug' => Str::slug('Smartphones'),
            'parent_id' => $celulares->id,
            'seo_title' => 'Últimos smartphones y teléfonos móviles',
            'seo_description' => 'Encuentra los smartphones más avanzados y eficientes del mercado.',
            'seo_keywords' => ['smartphones', 'telefonos moviles', 'iphone', 'android'],
            'image' => $getRandomImageAndCopy(Str::slug('Smartphones')),
        ]);
        Category::create([
            'name' => 'Smartwatches',
            'slug' => Str::slug('Smartwatches'),
            'parent_id' => $celulares->id,
            'seo_title' => 'Smartwatches y relojes inteligentes',
            'seo_description' => 'La mejor tecnología vestible para controlar tu salud y notificaciones.',
            'seo_keywords' => ['smartwatches', 'relojes inteligentes', 'apple watch', 'galaxy watch'],
            'image' => $getRandomImageAndCopy(Str::slug('Smartwatches')),
        ]);
        Category::create([
            'name' => 'Audífonos Inalámbricos (Earbuds)',
            'slug' => Str::slug('Audífonos Inalámbricos (Earbuds)'),
            'parent_id' => $celulares->id,
            'seo_title' => 'Audífonos inalámbricos y earbuds',
            'seo_description' => 'Disfruta de tu música sin cables con nuestros audífonos de alta calidad.',
            'seo_keywords' => ['audifonos inalambricos', 'earbuds', 'airpods', 'galaxy buds'],
            'image' => $getRandomImageAndCopy(Str::slug('Audífonos Inalámbricos (Earbuds)')),
        ]);
        $accesoriosCelulares = Category::create([
            'name' => 'Accesorios para Celulares',
            'slug' => Str::slug('Accesorios para Celulares'),
            'parent_id' => $celulares->id,
            'seo_title' => 'Accesorios esenciales para tu celular',
            'seo_description' => 'Fundas, cargadores y protectores para mantener tu smartphone seguro y funcional.',
            'seo_keywords' => ['accesorios celulares', 'fundas', 'cargadores', 'protectores pantalla'],
            'image' => $getRandomImageAndCopy(Str::slug('Accesorios para Celulares')),
        ]);

        Category::create([
            'name' => 'Fundas y Protectores',
            'slug' => Str::slug('Fundas y Protectores'),
            'parent_id' => $accesoriosCelulares->id,
            'seo_title' => 'Fundas y protectores para smartphones',
            'seo_description' => 'Protege tu teléfono con nuestra variedad de fundas y protectores de pantalla.',
            'seo_keywords' => ['fundas celular', 'protectores pantalla', 'carcasas'],
            'image' => $getRandomImageAndCopy(Str::slug('Fundas y Protectores')),
        ]);
        Category::create([
            'name' => 'Cargadores y Baterías',
            'slug' => Str::slug('Cargadores y Baterías'),
            'parent_id' => $accesoriosCelulares->id,
            'seo_title' => 'Cargadores y baterías externas',
            'seo_description' => 'Mantén tus dispositivos siempre cargados con nuestros cargadores y power banks.',
            'seo_keywords' => ['cargadores', 'baterias externas', 'power bank'],
            'image' => $getRandomImageAndCopy(Str::slug('Cargadores y Baterías')),
        ]);
        Category::create([
            'name' => 'Micas y Protectores de Pantalla',
            'slug' => Str::slug('Micas y Protectores de Pantalla'),
            'parent_id' => $accesoriosCelulares->id,
            'seo_title' => 'Micas y protectores de pantalla de alta resistencia',
            'seo_description' => 'Protege la pantalla de tu celular de arañazos y golpes.',
            'seo_keywords' => ['micas', 'protectores pantalla', 'cristal templado'],
            'image' => $getRandomImageAndCopy(Str::slug('Micas y Protectores de Pantalla')),
        ]);

        Category::create([
            'name' => 'Laptops',
            'slug' => Str::slug('Laptops'),
            'parent_id' => $computacion->id,
            'seo_title' => 'Laptops para trabajo y gaming',
            'seo_description' => 'Descubre nuestra selección de laptops potentes y versátiles para todas tus necesidades.',
            'seo_keywords' => ['laptops', 'portatiles', 'laptop gaming', 'ultrabooks'],
            'image' => $getRandomImageAndCopy(Str::slug('Laptops')),
        ]);
        $componentes = Category::create([
            'name' => 'Componentes para PC',
            'slug' => Str::slug('Componentes para PC'),
            'parent_id' => $computacion->id,
            'seo_title' => 'Componentes para armar o mejorar tu PC',
            'seo_description' => 'Tarjetas de video, procesadores, RAM, SSD y todo lo necesario para tu ordenador.',
            'seo_keywords' => ['componentes pc', 'gpu', 'cpu', 'ram', 'ssd'],
            'image' => $getRandomImageAndCopy(Str::slug('Componentes para PC')),
        ]);
        $perifericos = Category::create([
            'name' => 'Periféricos',
            'slug' => Str::slug('Periféricos'),
            'parent_id' => $computacion->id,
            'seo_title' => 'Periféricos esenciales para tu computadora',
            'seo_description' => 'Monitores, teclados, ratones y webcams para una experiencia completa.',
            'seo_keywords' => ['perifericos', 'monitores', 'teclados', 'ratones', 'webcams'],
            'image' => $getRandomImageAndCopy(Str::slug('Periféricos')),
        ]);

        Category::create([
            'name' => 'Tarjetas de Video (GPU)',
            'slug' => Str::slug('Tarjetas de Video (GPU)'),
            'parent_id' => $componentes->id,
            'seo_title' => 'Tarjetas de video de alto rendimiento',
            'seo_description' => 'Las mejores GPUs para gaming y diseño gráfico.',
            'seo_keywords' => ['tarjetas de video', 'gpu', 'nvidia', 'amd'],
            'image' => $getRandomImageAndCopy(Str::slug('Tarjetas de Video (GPU)')),
        ]);
        Category::create([
            'name' => 'Procesadores (CPU)',
            'slug' => Str::slug('Procesadores (CPU)'),
            'parent_id' => $componentes->id,
            'seo_title' => 'Procesadores Intel y AMD',
            'seo_description' => 'CPUs de última generación para potenciar el rendimiento de tu PC.',
            'seo_keywords' => ['procesadores', 'cpu', 'intel', 'amd'],
            'image' => $getRandomImageAndCopy(Str::slug('Procesadores (CPU)')),
        ]);
        Category::create([
            'name' => 'Tarjetas Madre',
            'slug' => Str::slug('Tarjetas Madre'),
            'parent_id' => $componentes->id,
            'seo_title' => 'Tarjetas madre para PC gaming y profesional',
            'seo_description' => 'La base de tu sistema: placas base compatibles con Intel y AMD.',
            'seo_keywords' => ['tarjetas madre', 'placas base', 'motherboard'],
            'image' => $getRandomImageAndCopy(Str::slug('Tarjetas Madre')),
        ]);
        Category::create([
            'name' => 'Memoria RAM',
            'slug' => Str::slug('Memoria RAM'),
            'parent_id' => $componentes->id,
            'seo_title' => 'Memoria RAM DDR4 y DDR5',
            'seo_description' => 'Mejora la velocidad y multitarea de tu PC con nuestra memoria RAM de alto rendimiento.',
            'seo_keywords' => ['memoria ram', 'ddr4', 'ddr5'],
            'image' => $getRandomImageAndCopy(Str::slug('Memoria RAM')),
        ]);
        Category::create([
            'name' => 'Almacenamiento (SSD, HDD)',
            'slug' => Str::slug('Almacenamiento (SSD, HDD)'),
            'parent_id' => $componentes->id,
            'seo_title' => 'Almacenamiento SSD y HDD para PC',
            'seo_description' => 'Discos de estado sólido (SSD) y discos duros (HDD) para todas tus necesidades de almacenamiento.',
            'seo_keywords' => ['almacenamiento', 'ssd', 'hdd', 'nvme'],
            'image' => $getRandomImageAndCopy(Str::slug('Almacenamiento (SSD, HDD)')),
        ]);

        Category::create([
            'name' => 'Monitores',
            'slug' => Str::slug('Monitores'),
            'parent_id' => $perifericos->id,
            'seo_title' => 'Monitores para PC y gaming',
            'seo_description' => 'Monitores de alta resolución y tasas de refresco para una visualización superior.',
            'seo_keywords' => ['monitores', 'pantallas', 'monitores curvos'],
            'image' => $getRandomImageAndCopy(Str::slug('Monitores')),
        ]);
        Category::create([
            'name' => 'Teclados',
            'slug' => Str::slug('Teclados'),
            'parent_id' => $perifericos->id,
            'seo_title' => 'Teclados mecánicos y ergonómicos',
            'seo_description' => 'Encuentra el teclado perfecto para escribir o jugar con comodidad y precisión.',
            'seo_keywords' => ['teclados', 'teclado mecanico', 'teclado inalambrico'],
            'image' => $getRandomImageAndCopy(Str::slug('Teclados')),
        ]);
        Category::create([
            'name' => 'Ratones (Mice)',
            'slug' => Str::slug('Ratones (Mice)'),
            'parent_id' => $perifericos->id,
            'seo_title' => 'Ratones gaming y de oficina',
            'seo_description' => 'Ratones de alta precisión y ergonomía para todo tipo de usuarios.',
            'seo_keywords' => ['ratones', 'mouse gaming', 'mouse inalambrico'],
            'image' => $getRandomImageAndCopy(Str::slug('Ratones (Mice)')),
        ]);
        Category::create([
            'name' => 'Webcams',
            'slug' => Str::slug('Webcams'),
            'parent_id' => $perifericos->id,
            'seo_title' => 'Webcams Full HD para streaming y videollamadas',
            'seo_description' => 'Cámaras web de alta calidad para tus reuniones online o transmisiones en vivo.',
            'seo_keywords' => ['webcams', 'camaras web', 'streaming'],
            'image' => $getRandomImageAndCopy(Str::slug('Webcams')),
        ]);

        Category::create([
            'name' => 'Auriculares (Over-ear, On-ear)',
            'slug' => Str::slug('Auriculares (Over-ear, On-ear)'),
            'parent_id' => $audioVideo->id,
            'seo_title' => 'Auriculares de diadema y supraaurales',
            'seo_description' => 'Disfruta de un sonido potente y claro con nuestros auriculares over-ear y on-ear.',
            'seo_keywords' => ['auriculares', 'cascos', 'over-ear', 'on-ear'],
            'image' => $getRandomImageAndCopy(Str::slug('Auriculares (Over-ear, On-ear)')),
        ]);
        Category::create([
            'name' => 'Bocinas y Sistemas de Sonido',
            'slug' => Str::slug('Bocinas y Sistemas de Sonido'),
            'parent_id' => $audioVideo->id,
            'seo_title' => 'Bocinas Bluetooth y sistemas de sonido',
            'seo_description' => 'Altavoces portátiles y sistemas de sonido envolvente para tu hogar.',
            'seo_keywords' => ['bocinas', 'altavoces', 'sistemas de sonido', 'bluetooth'],
            'image' => $getRandomImageAndCopy(Str::slug('Bocinas y Sistemas de Sonido')),
        ]);
        Category::create([
            'name' => 'Cámaras',
            'slug' => Str::slug('Cámaras'),
            'parent_id' => $audioVideo->id,
            'seo_title' => 'Cámaras digitales y de video',
            'seo_description' => 'Captura cada momento con nuestras cámaras de alta resolución y grabación 4K.',
            'seo_keywords' => ['camaras', 'camaras reflex', 'camaras mirrorless', 'camaras 4k'],
            'image' => $getRandomImageAndCopy(Str::slug('Cámaras')),
        ]);
        Category::create([
            'name' => 'Drones',
            'slug' => Str::slug('Drones'),
            'parent_id' => $audioVideo->id,
            'seo_title' => 'Drones con cámara para fotografía y video',
            'seo_description' => 'Explora el mundo desde nuevas perspectivas con nuestros drones profesionales y recreativos.',
            'seo_keywords' => ['drones', 'drones con camara', 'dji'],
            'image' => $getRandomImageAndCopy(Str::slug('Drones')),
        ]);

        Category::create([
            'name' => 'Cables y Adaptadores',
            'slug' => Str::slug('Cables y Adaptadores'),
            'parent_id' => $accesorios->id,
            'seo_title' => 'Cables y adaptadores para todos tus dispositivos',
            'seo_description' => 'Conecta todo con nuestra variedad de cables HDMI, USB, adaptadores y más.',
            'seo_keywords' => ['cables', 'adaptadores', 'hdmi', 'usb'],
            'image' => $getRandomImageAndCopy(Str::slug('Cables y Adaptadores')),
        ]);
        Category::create([
            'name' => 'Mochilas y Estuches',
            'slug' => Str::slug('Mochilas y Estuches'),
            'parent_id' => $accesorios->id,
            'seo_title' => 'Mochilas y estuches para laptops y gadgets',
            'seo_description' => 'Protege tus equipos con nuestras mochilas y estuches resistentes y con estilo.',
            'seo_keywords' => ['mochilas', 'estuches', 'mochilas laptop'],
            'image' => $getRandomImageAndCopy(Str::slug('Mochilas y Estuches')),
        ]);
        Category::create([
            'name' => 'Discos Duros Externos y USB',
            'slug' => Str::slug('Discos Duros Externos y USB'),
            'parent_id' => $accesorios->id,
            'seo_title' => 'Discos duros externos y unidades USB',
            'seo_description' => 'Almacena y transporta tus datos de forma segura con nuestros discos externos y memorias USB.',
            'seo_keywords' => ['discos duros externos', 'usb', 'memorias usb'],
            'image' => $getRandomImageAndCopy(Str::slug('Discos Duros Externos y USB')),
        ]);
        Category::create([
            'name' => 'Otros Gadgets',
            'slug' => Str::slug('Otros Gadgets'),
            'parent_id' => $accesorios->id,
            'seo_title' => 'Otros gadgets y dispositivos tecnológicos',
            'seo_description' => 'Descubre una variedad de gadgets innovadores y útiles para tu día a día.',
            'seo_keywords' => ['gadgets', 'tecnologia', 'innovacion'],
            'image' => $getRandomImageAndCopy(Str::slug('Otros Gadgets')),
        ]);
    }
}