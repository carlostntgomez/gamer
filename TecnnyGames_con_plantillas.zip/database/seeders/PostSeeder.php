<?php

namespace Database\Seeders;

use App\Models\Post;
use App\Models\Tag;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $driver = DB::connection()->getDriverName();
        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        }

        DB::table('posts')->truncate();
        DB::table('tags')->truncate();
        DB::table('post_tag')->truncate();

        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        }

        // Create some tags
        Tag::factory()->count(10)->create();
        $tagIds = Tag::pluck('id')->toArray();

        // Get the list of available sample images for featured images
        $imagePath = public_path('imagenes de muestra');
        $imageFiles = File::files($imagePath);

        // Create posts and attach media if images are available
        if (empty($imageFiles)) {
            $this->command->warn('No sample images found in public/imagenes de muestra. Seeding posts without featured images.');
            Post::factory()
                ->count(20)
                ->create()
                ->each(function (Post $post) use ($tagIds) {
                    // Attach 1 to 3 random tags
                    $post->tags()->attach(fake()->randomElements($tagIds, fake()->numberBetween(1, 3)));
                });
            return;
        }

        Post::factory()
            ->count(20)
            ->create()
            ->each(function (Post $post) use ($tagIds, $imageFiles) {
                // Attach 1 to 3 random tags
                $post->tags()->attach(fake()->randomElements($tagIds, fake()->numberBetween(1, 3)));

                // Attach a random featured image
                $randomImageFile = fake()->randomElement($imageFiles);
                $post->addMedia($randomImageFile->getRealPath())
                    ->preservingOriginal()
                    ->toMediaCollection('featured_image');
            });
    }
}
