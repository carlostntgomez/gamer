<?php

namespace Database\Seeders;

use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class OrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $driver = DB::connection()->getDriverName();
        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        }

        DB::table('orders')->truncate();
        DB::table('order_items')->truncate();
        // Addresses are handled by AddressFactory, which might create new ones, so we don't truncate them here to avoid issues with other seeders

        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        }

        Order::factory()
            ->count(10)
            ->create()
            ->each(function (Order $order) {
                OrderItem::factory()
                    ->count(fake()->numberBetween(1, 5))
                    ->create(['order_id' => $order->id]);

                // Calculate total based on order items
                $total = $order->orderItems->sum(fn ($item) => $item->quantity * $item->price);
                $order->update(['total' => $total]);
            });
    }
}
