<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\Discount;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Discount>
 */
class DiscountFactory extends Factory
{
    protected $model = Discount::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $type = $this->faker->randomElement(['percentage', 'fixed']);
        $value = $type === 'percentage' ? $this->faker->numberBetween(5, 50) : $this->faker->randomFloat(2, 5, 50);
        $appliesTo = $this->faker->randomElement(['all', 'products', 'categories']);

        $productIds = null;
        $categoryIds = null;

        if ($appliesTo === 'products') {
            $productIds = Product::inRandomOrder()->limit($this->faker->numberBetween(1, 3))->pluck('id')->toArray();
        } elseif ($appliesTo === 'categories') {
            $categoryIds = Category::inRandomOrder()->limit($this->faker->numberBetween(1, 2))->pluck('id')->toArray();
        }

        return [
            'code' => $this->faker->unique()->word() . $this->faker->randomNumber(3),
            'type' => $type,
            'value' => $value,
            'min_amount' => $this->faker->boolean(30) ? $this->faker->randomFloat(2, 20, 100) : null,
            'max_uses' => $this->faker->boolean(50) ? $this->faker->numberBetween(10, 100) : null,
            'uses' => $this->faker->numberBetween(0, 5),
            'starts_at' => $this->faker->dateTimeBetween('-1 month', '+1 week'),
            'expires_at' => $this->faker->boolean(70) ? $this->faker->dateTimeBetween('+1 week', '+6 months') : null,
            'is_active' => $this->faker->boolean(80),
            'applies_to' => $appliesTo,
            'product_ids' => $productIds,
            'category_ids' => $categoryIds,
        ];
    }
}
