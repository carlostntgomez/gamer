<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $price = $this->faker->randomFloat(2, 10, 500);
        $name = $this->faker->words(3, true);

        return [
            'name' => $name,
            'sku' => $this->faker->unique()->ean8(),
            'description' => $this->faker->paragraph(5),
            'other_content' => $this->faker->paragraphs(3, true),
            'price' => $price,
            'sale_price' => $this->faker->optional(0.5)->randomFloat(2, 5, $price - 1),
            'vendor' => $this->faker->company(),
            'type' => $this->faker->word(),
            'stock' => $this->faker->numberBetween(0, 100),
            'is_featured' => $this->faker->boolean(20),
            'condition' => $this->faker->randomElement(['nuevo', 'usado']),
            'colors' => $this->faker->randomElements(['Rojo', 'Verde', 'Azul', 'Blanco', 'Negro'], rand(1, 3)),
            'video_url' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'additional_info' => [
                'Peso' => $this->faker->numberBetween(100, 5000) . 'g',
                'Dimensiones' => $this->faker->numberBetween(1, 100) . 'x' . $this->faker->numberBetween(1, 100) . 'x' . $this->faker->numberBetween(1, 100) . ' cm',
            ],
            'delivery_date_message' => 'Entrega estimada en ' . $this->faker->numberBetween(2, 7) . ' días.',
            'seo_title' => $name . ' - ' . $this->faker->company(),
            'seo_description' => $this->faker->sentence(15),
            'seo_keywords' => implode(', ', $this->faker->words(5)),
            'brand_id' => \App\Models\Brand::inRandomOrder()->first()->id,
            // 'images' and 'slug' are handled automatically (by seeder and sluggable trait)
        ];
    }
}
