<x-app-layout>
    <!-- main section start-->
    <main>
        <!-- breadcrumb start -->
        <section class="breadcrumb-area">
            <div class="container">
                <div class="col">
                    <div class="row">
                        <div class="breadcrumb-index">
                            <!-- breadcrumb-list start -->
                            <ul class="breadcrumb-ul">
                                <li class="breadcrumb-li">
                                    <a class="breadcrumb-link" href="{{ route('home') }}">Home</a>
                                </li>
                                <li class="breadcrumb-li">
                                    <span class="breadcrumb-text">Terms & condition</span>
                                </li>
                            </ul>
                            <!-- breadcrumb-list end -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb end -->
        <!-- terms-rules start -->
        <section class="terms-rules section-ptb ">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <!-- section title start -->
                        <div class="section-capture">
                            <div class="section-title">
                                <h2 data-animate="animate__fadeInUp"><span>Terms & conditions</span></h2>
                            </div>
                        </div>
                        <!-- section title end -->
                        <!-- Terms-banner-rules start -->
                        <div class="terms-banner-rules">
                            <div class="banner-wrap" data-animate="animate__fadeInUp">
                                <div class="banner-bgimg" style="background-image: url('{{ asset('img/team/terms.jpg') }}');"></div>
                                <div class="banner-img">
                                    <img src="{{ asset('img/team/terms.jpg') }}" class="img-fluid" alt="Terms-&-conditions">
                                </div>
                            </div>
                            <div class="rules-wrap">
                                <h6 data-animate="animate__fadeInUp">Restriction</h6>
                                <ul class="terms-ul">
                                    <li class="terms-li" data-animate="animate__fadeInUp">
                                        <p>There are many variations of passages of lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                                    </li>
                                    <li class="terms-li" data-animate="animate__fadeInUp">
                                        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.</p>
                                    </li>
                                    <li class="terms-li" data-animate="animate__fadeInUp">
                                        <p>Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Terms-banner-rules end -->
                    </div>
                </div>
            </div>
        </section>
        <!-- terms-rules end -->
        <!-- temrs-condition start -->
        <section class="temrs-condition section-ptb bg-color">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="t-condition-block">
                            <ul class="condition-ul">
                                <li data-animate="animate__fadeInUp">
                                    <h6>Introduction words</h6>
                                    <p>There are many variations of passages of lorem Ipsum available, by injected, or words which don't look even slightly believable.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>Intellectual property</h6>
                                    <p>If you are going to use a passage of lorem ipsum, you need to be sure there isn't anything hidden in the middle of text.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>Your content</h6>
                                    <p>All the lorem ipsum generators on the Internet tend to repeat as necessary, making this the first true generator on the Internet.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>Sever ability</h6>
                                    <p>It uses a dictionary of over 200 Latin words, combined with a handful of model sentence, to looks reasonable.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>No majority</h6>
                                    <p>It was popularized in the 1960s with the release of sheets containing passages, and more recently versions of lorem ipsum.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>Variation terms</h6>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, beatae vitae dicta sunt explicabo.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>Sheets release</h6>
                                    <p>Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe sint et molestiae non recusandae.</p>
                                </li>
                                <li data-animate="animate__fadeInUp">
                                    <h6>Maxim placate</h6>
                                    <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil maxime placeat facere possimus, omnis dolor repellendus.</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- temrs-condition end -->
        <!-- need-help start -->
        <section class="need-help section-ptb">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <!-- section title start -->
                        <div class="section-capture">
                            <div class="section-title">
                                <h2 data-animate="animate__fadeInUp"><span>Need help</span></h2>
                            </div>
                        </div>
                        <!-- section title end -->
                        <!-- need-help grid start -->
                        <div class="need-wrap">
                            <ul class="need-ul">
                                <li class="need-li" data-animate="animate__fadeInUp">
                                    <div class="need-img">
                                        <img src="{{ asset('img/team/mail.jpg') }}" class="img-fluid" alt="mail">
                                    </div>
                                    <div class="need-block">
                                        <span class="need-help-icon"><i class="bi bi-envelope"></i></span>
                                        <div class="need-help-text">
                                            <h6>Chat with us</h6>
                                            <p class="title">Send us an email</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="need-li" data-animate="animate__fadeInUp">
                                    <div class="need-img">
                                        <img src="{{ asset('img/team/call.jpg') }}" class="img-fluid" alt="call">
                                    </div>
                                    <div class="need-block">
                                        <span class="need-help-icon"><i class="bi bi-telephone"></i></span>
                                        <div class="need-help-text">
                                            <h6>Speak with us</h6>
                                            <p class="title">Give us a call toady</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="need-li" data-animate="animate__fadeInUp">
                                    <div class="need-img">
                                        <img src="{{ asset('img/team/location.jpg') }}" class="img-fluid" alt="location">
                                    </div>
                                    <div class="need-block">
                                        <span class="need-help-icon"><i class="bi bi-geo"></i></span>
                                        <div class="need-help-text">
                                            <h6>Locate a store</h6>
                                            <p class="title">Describe your project</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <!-- need-help grid end -->
                    </div>
                </div>
            </div>
        </section>
        <!-- need-help end -->
    </main>
</x-app-layout>
