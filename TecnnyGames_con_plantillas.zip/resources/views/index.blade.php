<x-app-layout>
    <!-- main start -->
    <main id="main-content">
        @include('components.home.slider')
        @include('components.home.top-categories')
        @include('components.home.banner-grid')
        @include('components.home.banner-offer')
        @include('components.home.trending-products')
        @include('components.home.featured-products')
        @include('components.home.brand-logo')
    </main>
    <!-- main end -->
</x-app-layout>
