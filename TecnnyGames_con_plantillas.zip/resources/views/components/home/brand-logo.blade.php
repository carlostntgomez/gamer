            <!-- brand-logo start -->
            <div class="brand-logo section-ptb">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="brand-logo-wrap">
                                <div class="brand-logo-slider owl-carousel owl-theme" id="brand-logo8">
                                    <div class="item" data-animate="animate__fadeInUp">
                                        <a href="javascript:void(0)">
                                            <span class="brand-img">
                                                <img src="{{ asset('img/brand-logo/home8-brand-logo1.png') }}" class="img-fluid" alt="brand-logo1">
                                            </span>
                                        </a>
                                    </div>
                                    <div class="item" data-animate="animate__fadeInUp">
                                        <a href="javascript:void(0)">
                                            <span class="brand-img">
                                                <img src="{{ asset('img/brand-logo/home8-brand-logo2.png') }}" class="img-fluid" alt="brand-logo2">
                                            </span>
                                        </a>
                                    </div>
                                    <div class="item" data-animate="animate__fadeInUp">
                                        <a href="javascript:void(0)">
                                            <span class="brand-img">
                                                <img src="{{ asset('img/brand-logo/home8-brand-logo3.png') }}" class="img-fluid" alt="brand-logo3">
                                            </span>
                                        </a>
                                    </div>
                                    <div class="item" data-animate="animate__fadeInUp">
                                        <a href="javascript:void(0)">
                                            <span class="brand-img">
                                                <img src="{{ asset('img/brand-logo/home8-brand-logo4.png') }}" class="img-fluid" alt="brand-logo4">
                                            </span>
                                        </a>
                                    </div>
                                    <div class="item" data-animate="animate__fadeInUp">
                                        <a href="javascript:void(0)">
                                            <span class="brand-img">
                                                <img src="{{ asset('img/brand-logo/home8-brand-logo5.png') }}" class="img-fluid" alt="brand-logo5">
                                            </span>
                                        </a>
                                    </div>
                                    <div class="item" data-animate="animate__fadeInUp">
                                        <a href="javascript:void(0)">
                                            <span class="brand-img">
                                                <img src="{{ asset('img/brand-logo/home8-brand-logo6.png') }}" class="img-fluid" alt="brand-logo6">
                                            </span>  
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- brand-logo end -->