        <!-- footer start -->
        <section class="footer-area section-ptb">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="footer-list">
                            <ul class="footer-ul">
                                <li class="footer-li footer-contact" data-animate="animate__fadeInUp">
                                    <ul class="ftlist-ul">
                                        <li class="ftlist-li">
                                            <div class="footer-logo">
                                                <a href="{{ route('home') }}" class="theme-logo">
                                                    <img src="{{ asset('img/logo/footer8-logo.png') }}" class="img-fluid" alt="footer-logo">
                                                </a>
                                            </div>
                                            <ul class="ftcontact-ul" id="footer-store-information">
                                                <li class="ftcontact-li">
                                                    <div class="ft-contact-add">
                                                        <span class="ft-contact-icon"><i class="fa-solid fa-phone"></i></span>
                                                        <a href="#" class="ft-contact-address">(+63) 0123 456 789</a>
                                                    </div>
                                                </li>
                                                <li class="ftcontact-li">
                                                    <div class="ft-contact-add ft-contact-place">
                                                        <span class="ft-contact-icon"><i class="fa-solid fa-location-dot"></i></span>
                                                        <span class="ft-contact-address">
                                                            <span>20 Princess road, london,</span>
                                                            <span>greater london NW1, UK</span>
                                                        </span>
                                                    </div>
                                                </li>
                                                <li class="ftcontact-li">
                                                    <div class="ft-contact-add">
                                                        <span class="ft-contact-icon"><i class="fa-regular fa-envelope"></i></span>
                                                        <a href="mailto:demo@demo.com" class="ft-contact-address">demo@demo.com</a>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="footer-social">
                                                <ul class="social-icon">
                                                    <!-- facebook-icon start -->
                                                    <li>
                                                        <a href="https://www.facebook.com/">
                                                            <span class="icon-social facebook"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path></svg></span>
                                                        </a>
                                                    </li>
                                                    <!-- facebook-icon end -->
                                                    <!-- twitter-icon start -->
                                                    <li>
                                                        <a href="https://twitter.com/">
                                                            <span class="icon-social twitter"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path></svg></span>
                                                        </a>
                                                    </li>
                                                    <!-- twitter-icon end -->
                                                    <!-- pinterest-icon start -->
                                                    <li>
                                                        <a href="https://in.pinterest.com/">
                                                            <span class="icon-social pinterest"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M204 6.5C101.4 6.5 0 74.9 0 185.6 0 256 39.6 296 63.6 296c9.9 0 15.6-27.6 15.6-35.4 0-9.3-23.7-29.1-23.7-67.8 0-80.4 61.2-137.4 140.4-137.4 68.1 0 118.5 38.7 118.5 109.8 0 53.1-21.3 152.7-90.3 152.7-24.9 0-46.2-18-46.2-43.8 0-37.8 26.4-74.4 26.4-113.4 0-66.2-93.9-54.2-93.9 25.8 0 16.8 2.1 35.4 9.6 50.7-13.8 59.4-42 147.9-42 209.1 0 18.9 2.7 37.5 4.5 56.4 3.4 3.8 1.7 3.4 6.9 1.5 50.4-69 48.6-82.5 71.4-172.8 12.3 23.4 44.1 36 69.3 36 106.2 0 153.9-103.5 153.9-196.8C384 71.3 298.2 6.5 204 6.5z"></path></svg></span>
                                                        </a>
                                                    </li>
                                                    <!-- pinterest-icon end -->
                                                    <!-- instagram-icon start -->
                                                    <li>
                                                        <a href="https://www.instagram.com/">
                                                            <span class="icon-social instagram"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg></span>
                                                        </a>
                                                    </li>
                                                    <!-- instagram-icon end -->
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer-li"  data-animate="animate__fadeInUp">
                                    <ul class="ftlist-ul">
                                        <li class="ftlist-li">
                                            <h6 class="ftlist-title">Find categories</h6>
                                            <a href="#footer-my-account" class="ftlist-title" data-bs-toggle="collapse" aria-expanded="false">
                                                <span>Find categories</span>
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                            <ul class="ftlink-ul collapse" id="footer-my-account">
                                                <li class="ftlink-li">
                                                    <a href="{{ route('product.show', ['slug' => 'PLACEHOLDER_SLUG']) }}">Desktop</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('product.show', ['slug' => 'PLACEHOLDER_SLUG']) }}">Laptops &amp; notebooks</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('product.show', ['slug' => 'PLACEHOLDER_SLUG']) }}">Components</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('product.show', ['slug' => 'PLACEHOLDER_SLUG']) }}">Tablets</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('product.show', ['slug' => 'PLACEHOLDER_SLUG']) }}">Software</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('product.show', ['slug' => 'PLACEHOLDER_SLUG']) }}">Phone &amp; PDAS</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer-li" data-animate="animate__fadeInUp">
                                    <ul class="ftlist-ul">
                                        <li class="ftlist-li">
                                            <h6 class="ftlist-title">Customer care</h6>
                                            <a href="#footer-extras" class="ftlist-title" data-bs-toggle="collapse" aria-expanded="false">
                                                <span>Customer care</span>
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                            <ul class="ftlink-ul collapse" id="footer-extras">
                                                <li class="ftlink-li">
                                                    <a href="{{ route('page.contact_us') }}">Contact us</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('page.about_us') }}">About us</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('page.faq') }}">Faq's</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('page.privacy_policy') }}">Privacy policy</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('page.terms_condition') }}">Terms & condition</a>
                                                </li>
                                                <li class="ftlink-li">
                                                    <a href="{{ route('wishlist.index') }}">Wishlist</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer-li footer-content-info" data-animate="animate__fadeInUp">
                                    <ul class="ftlist-ul">
                                        <li class="ftlist-li">
                                            <h6 class="ftlist-title">Join our newsletter</h6>
                                            <div class="footer-content">
                                                <div class="footer-info">
                                                    <p>Subscribe the newsletter for all the latest updates</p>
                                                </div>
                                                <div class="news-content">
                                                    <form method="post" id="contact_form" class="contact-form">
                                                        <input type="hidden" name="form_type" value="customer">
                                                        <input type="hidden" name="utf8" value="✓">
                                                        <input type="hidden" name="contact[tags]" value="newsletter">
                                                        <div class="subscribe-block">
                                                            <input type="email" name="contact[email]" class="email mail" id="E-mail" value="" placeholder="email@example.com" autocapitalize="off" required="">
                                                            <div class="email-submit">
                                                                <button type="submit" class="btn btn-style" name="commit" id="Subscribe">Subscribe</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- footer end -->
        <!-- footer-copyright start -->
        <footer class="ft-copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="ft-copyright">
                            <ul class="ft-copryright-ul">
                                <li class="ft-copryright-li ft-copyright-text">
                                    <p>Copyright  2025 ecommerce by <a href="#">spacingtech</a></p>
                                </li>
                                <li class="ft-copryright-li ft-payment">
                                    <ul class="payment-icon">
                                       <li>
                                            <a href="#">
                                                <img src="{{ asset('img/payment/home5-pay1.png') }}" class="img-fluid" alt="pay6">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img src="{{ asset('img/payment/home5-pay2.png') }}" class="img-fluid" alt="pay5">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img src="{{ asset('img/payment/home5-pay3.png') }}" class="img-fluid" alt="pay4">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img src="{{ asset('img/payment/home5-pay4.png') }}" class="img-fluid" alt="pay2">
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer-copyright end -->