<x-app-layout>
    <main>
        <!-- breadcrumb start -->
        <section class="breadcrumb-area">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="breadcrumb-index">
                            <!-- breadcrumb-list start -->
                            <ul class="breadcrumb-ul">
                                <li class="breadcrumb-li">
                                    <a class="breadcrumb-link" href="{{ route('home') }}">Home</a>
                                </li>
                                <li class="breadcrumb-li">
                                    <span class="breadcrumb-text">Traking</span>
                                </li>
                            </ul>
                            <!-- breadcrumb-list end -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb end -->
        <!-- tracking start -->
        <section class="track-block  section-ptb">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="track-area">
                            <div class="track-price">
                                <ul class="track-order" data-animate="animate__fadeInUp">
                                    <li  class="track-li">
                                        <h6>Your order id is: 121</h6>
                                    </li>
                                    <li  class="track-li">
                                        <span class="track-status">Status:</span>
                                        Picked by courier
                                    </li>
                                </ul>
                            </div>
                            <div class="track-info" data-animate="animate__fadeInUp">
                                <div class="track-content">
                                    <div class="track-wrap active">
                                        <span class="track-icon"><i class="fa fa-check"></i></span>
                                        <span class="track-text">Order confirmed</span>
                                    </div>
                                    <div class="track-wrap active">
                                        <span class="track-icon"><i class="fa fa-user"></i></span>
                                        <span class="track-text">Picked by courier</span>
                                    </div>
                                    <div class="track-wrap">
                                        <span class="track-icon"><i class="fa fa-truck"></i></span>
                                        <span class="track-text"> On the way </span>
                                    </div>
                                    <div class="track-wrap">
                                        <span class="track-icon"><i class="fa fa-archive"></i></span>
                                        <span class="track-text">Ready for pickup</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- tracking end -->
    </main>
</x-app-layout>