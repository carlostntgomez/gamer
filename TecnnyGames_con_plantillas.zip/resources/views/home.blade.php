<x-app-layout>
    <x-home.slider />
    <x-home.top-categories />
    <x-home.banner-grid />
    <x-home.trending-products />
    <x-home.banner-offer />
    <x-home.special-products />
    <x-home.brand-logo />
</x-app-layout>